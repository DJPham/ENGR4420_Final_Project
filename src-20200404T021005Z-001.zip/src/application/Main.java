package application;
	
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;


public class Main extends Application {
	@Override
	public void start(Stage primaryStage) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("CalcUI.fxml"));
			primaryStage.setTitle("Inflation Calculator");
			primaryStage.setScene(new Scene(root));
			primaryStage.show();
	}
	
	public static void main(String[] args) {
		launch(args);
	}
	
	private boolean killBrazil = false; //Set to true to effectively remove Brazil
	private int machineState=0;
	private int prevMachineState=0;
	private double countryOne, countryTwo;
	private int comp1IDX, comp2IDX, compYear, winningCountry;
	private String[] countries; //Used to initialize the ArrayList
	private ArrayList<String> selectableCountries = new ArrayList<String>(); //Keeps track of usable countries
	private ArrayList<String> selectableYears = new ArrayList<String>(); //Keeps track of usable years
	

	private double inflationCalSinglePoint(int nationIndex, int yearValue)
	{
	double result=0;
	int index=nationIndex;
	if(killBrazil)index++;
	switch(index)
	{
	case 0: result = 0.00000003*Math.pow(yearValue, 6) - 0.000005*Math.pow(yearValue, 5) + 0.0001*Math.pow(yearValue, 4) + 0.0069*Math.pow(yearValue, 3) - 0.4254*Math.pow(yearValue, 2) + 5.993*yearValue - 13.449; //Brazil
		break;	
	case 1: result = 0.00003*Math.pow(yearValue, 3)- 0.0033*Math.pow(yearValue, 2) + 0.1287*yearValue + 0.1384; //Canada
		break;	
	case 2: result = 0.0001*Math.pow(yearValue, 3) - 0.011*Math.pow(yearValue, 2) + 0.4093*yearValue - 3.0378; // China
		break;	
	case 3: result = 0.00004*Math.pow(yearValue, 3) - 0.0036*Math.pow(yearValue, 2)+0.143*yearValue-0.2451; // France
		break;	
	case 4: result = 0.00002*Math.pow(yearValue, 3)-0.0019*Math.pow(yearValue, 2)+0.0967*yearValue - 0.0421; // Germany
		break;	
	case 5: result = 0.0000000006*Math.pow(yearValue, 6)- 0.00000007*Math.pow(yearValue, 5) - 0.000004*Math.pow(yearValue, 4) + 0.0011*Math.pow(yearValue, 3) - 0.0569*Math.pow(yearValue, 2) + 1.2287*yearValue - 4.9206; // India
		break;	
	case 6: result = 0.00006*Math.pow(yearValue, 3) - 0.0058*Math.pow(yearValue, 2) + 0.2236*yearValue - 0.6254; // Italy
		break;	
	case 7: result = 0.000000002*Math.pow(yearValue, 6) - 0.0000005*Math.pow(yearValue, 5) + 0.00005*Math.pow(yearValue, 4) - 0.0023*Math.pow(yearValue, 3) + 0.047*Math.pow(yearValue, 2) - 0.3202*yearValue - 0.3837; //Japan
		break;	
	case 8: result = 0.0000000004*Math.pow(yearValue, 6) - 0.00000009*Math.pow(yearValue, 5) + 0.000007*Math.pow(yearValue, 4) - 0.0002*Math.pow(yearValue, 3) + 0.0009*Math.pow(yearValue, 2) + 0.0919*yearValue + 0.5629; // United Kingdom
		break;	
	case 9: result = 0.00004*Math.pow(yearValue, 3) - 0.0052*Math.pow(yearValue, 2) + 0.2148*yearValue - 0.4671; // United States
		break;	
	default:
	}
	return result;	
	}
	
	
	
	public void startup() {
	
	if(killBrazil)countries = new String[]{"Canada","China","France","Germany","India","Italy","Japan","United Kingdom","United States"};	
	else countries = new String[]{"Brazil", "Canada","China","France","Germany","India","Italy","Japan","United Kingdom","United States"};	
	for(int i=1960; i<=2022; i++)
	{
	selectableYears.add(Integer.toString(i));
	}
	for(int i=0; i<countries.length; i++)
	{
	selectableCountries.add(countries[i]);	
	}
	}
	
	public int getMachState()
	{
	return machineState;	
	}
	
	public boolean machStateChange()
	{
	if(machineState==prevMachineState)return false;
	return true;
	}
	
	public void confirmMachineStateChange()
	{
	prevMachineState=machineState;	
	}
	
	public void setMachState(int mach)
	{
	machineState = mach;	
	}
	
	public double calculateInflationSingle(int nationIDX,int year)
	{
	return BigDecimal.valueOf(inflationCalSinglePoint(nationIDX,year)).setScale(3, RoundingMode.HALF_UP).doubleValue();
	}
	
	
	public void compareCountries(int country1IDX, int country2IDX, int year)
	{
	countryOne = calculateInflationSingle(country1IDX, year);
	countryTwo = calculateInflationSingle(country2IDX, year);
	comp1IDX=country1IDX;
	comp2IDX=country2IDX;
	compYear = year;
	if(countryOne<countryTwo)winningCountry=1;
	else if(countryOne>countryTwo)winningCountry=2;
	else winningCountry=0;
	}
	
	public String getPredictionResult(int nationIDX, int year)
	{
	String result="";
	double inflation = calculateInflationSingle(nationIDX, year);
	result = result + "Nation: " + countries[nationIDX] + '\n';
	result = result + "Year: " + Integer.toString((year+1960)) + '\n';
	result = result + "Predicted Inflation: "+ Double.toString(inflation) +'%'+ '\n';
	return result;
	}
	
	public String getPredictionResultCountryOne()
	{
	String result="";
	result = result + "Nation: " + countries[comp1IDX] + '\n';
	result = result + "Year: " + Integer.toString((compYear+1960)) + '\n';
	result = result + "Predicted Inflation: "+ Double.toString(countryOne) +'%'+ '\n';
	return result;	
	}
	
	public String getPredictionResultCountryTwo()
	{
	String result="";
	result = result + "Nation: " + countries[comp2IDX] + '\n';
	result = result + "Year: " + Integer.toString((compYear+1960)) + '\n';
	result = result + "Predicted Inflation: "+ Double.toString(countryTwo) +'%'+ '\n';
	return result;	
	}
	
	public String getComparisonResult()
	{
	String result = "";
	switch(winningCountry)
	{
	case 1:
	result = result + countries[comp1IDX] + " has an inflation rate of " + Double.toString(countryOne) + "%." + '\n'+"This is less than " + countries[comp2IDX] + " with an inflation rate of " + Double.toString(countryTwo) + "%." + '\n';
	result = result + countries[comp1IDX] + " has the lower rate of inflation for the year " + Integer.toString((compYear+1960))+'!'+'\n';
	break;
	case 2:
		result = result + countries[comp2IDX] + " has an inflation rate of " + Double.toString(countryTwo) + "%." + '\n'+"This is less than " + countries[comp1IDX] + " with an inflation rate of " + Double.toString(countryOne) + "%." + '\n';
		result = result + countries[comp2IDX] + " has the lower rate of inflation for the year " + Integer.toString((compYear+1960))+'!'+'\n';
		break;
	case 0:
	    result = result + "The nations " + countries[comp1IDX] + " and " + countries[comp2IDX] + " both have an inflation rate of " + Double.toString(countryTwo) + "%." + '\n';
	    result = result + "They are tied in the year " + Integer.toString((compYear+1960)) + '.' + '\n';
		break;
	default:
	
	
	
	}
	return result;
		
	}
	
	public ArrayList<String> getValidYears()
	{
	return selectableYears;
	}
	
	public ArrayList<String> getValidCountries()
	{
	return selectableCountries;	
	}
			
	
	
}

