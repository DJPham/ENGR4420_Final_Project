package application;

import javax.xml.bind.JAXBException;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;
import javafx.util.Duration;

public class CalcUIController {
	Main calc;
	ObservableList<String> countryList;
	ObservableList<String> yearList;

	@FXML
	private void initialize() throws JAXBException {
		calc = new Main();
		changeState(0);
		calc.startup();
		changeState(1);
		countryList = FXCollections.observableArrayList(calc.getValidCountries());
		yearList = FXCollections.observableArrayList(calc.getValidYears());
		Timeline update = new Timeline(new KeyFrame(Duration.millis(500), new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				UIupdate();
			}

		}));
		update.setCycleCount(Timeline.INDEFINITE);
		update.play();

		// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<mainPane>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\\
		EventHandler<MouseEvent> mainPaneSingleHandL = new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent e) {
				changeState(2);
			}
		};
		mainPrediction.addEventHandler(MouseEvent.MOUSE_CLICKED, mainPaneSingleHandL);

		EventHandler<MouseEvent> mainPaneCompHandL = new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent e) {
				changeState(4);
			}
		};
		mainComparison.addEventHandler(MouseEvent.MOUSE_CLICKED, mainPaneCompHandL);

		EventHandler<MouseEvent> mainPaneAbtHandL = new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent e) {
				changeState(6);
			}
		};
		mainAbout.addEventHandler(MouseEvent.MOUSE_CLICKED, mainPaneAbtHandL);

		EventHandler<MouseEvent> mainPaneExitHandL = new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent e) {
				System.exit(0);
			}
		};
		mainExit.addEventHandler(MouseEvent.MOUSE_CLICKED, mainPaneExitHandL);

		// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<mainPane>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\\
		// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\\
		// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<proPainPredictor>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\\
		EventHandler<MouseEvent> proPainPredictMainHandL = new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent e) {
				changeState(1);
			}
		};
		proPainPredictorMain.addEventHandler(MouseEvent.MOUSE_CLICKED, proPainPredictMainHandL);

		EventHandler<MouseEvent> proPainPredictSingleHandL = new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent e) {
				if (!proPainPredictorCountry.getSelectionModel().isEmpty()
						&& !proPainPredictorYear.getSelectionModel().isEmpty()) {
					proPanePredictorAlertText.setVisible(false);
					changeState(3);
				} else {
					proPanePredictorAlertText.setVisible(true);
				}
			}
		};
		proPainPredictorPredict.addEventHandler(MouseEvent.MOUSE_CLICKED, proPainPredictSingleHandL);
		// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<proPainPredictor>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\\
		// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\\
		// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<proPainPredictorResult>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\\
		EventHandler<MouseEvent> proPainPredictResMainHandL = new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent e) {
				changeState(1);
			}
		};
		proPainPredictorResultMain.addEventHandler(MouseEvent.MOUSE_CLICKED, proPainPredictResMainHandL);

		EventHandler<MouseEvent> proPainPredictAgainHandL = new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent e) {
				changeState(2);
			}
		};
		proPainPredictorResultAgain.addEventHandler(MouseEvent.MOUSE_CLICKED, proPainPredictAgainHandL);

		// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<proPainPredictorResult>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\\
		// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\\
		// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<proPainComparator>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\\
		EventHandler<MouseEvent> proPainCompHandL = new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent e) {
				if (!proPaneComparatorCountry1.getSelectionModel().isEmpty()
						&& !proPaneComparatorCountry2.getSelectionModel().isEmpty()
						&& !proPaneComparatorYear.getSelectionModel().isEmpty()) {
					proPaneComparatorAlertText.setVisible(false);
					changeState(5);
				} else {
					proPaneComparatorAlertText.setVisible(true);
				}
			}
		};
		proPaneComparatorCompare.addEventHandler(MouseEvent.MOUSE_CLICKED, proPainCompHandL);

		EventHandler<MouseEvent> proPainCompMainHandL = new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent e) {
				changeState(1);
			}
		};
		proPaneComparatorMain.addEventHandler(MouseEvent.MOUSE_CLICKED, proPainCompMainHandL);

		// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<proPaneComparator>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\\
		// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\\
		// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<proPaneComparatorResult>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\\

		EventHandler<MouseEvent> proPanePredictResMainHandL = new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent e) {
				changeState(1);
			}
		};
		proPaneComparatorResultMain.addEventHandler(MouseEvent.MOUSE_CLICKED, proPanePredictResMainHandL);

		EventHandler<MouseEvent> proPanePredictAgainHandL = new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent e) {
				changeState(4);
			}
		};
		proPaneComparatorResultAgain.addEventHandler(MouseEvent.MOUSE_CLICKED, proPanePredictAgainHandL);

		// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<proPaneComparatorResult>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\\
		// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\\
		// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<abtPane>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\\

		EventHandler<MouseEvent> aboutPaneMain = new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent e) {
				changeState(1);
			}
		};
		abtPaneMain.addEventHandler(MouseEvent.MOUSE_CLICKED, aboutPaneMain);

		// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<abtPane>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\\

	}

	@FXML
	private Pane startPane;

	@FXML
	private Pane mainPane;

	@FXML
	private Button mainPrediction;

	@FXML
	private Button mainComparison;

	@FXML
	private Button mainExit;

	@FXML
	private Button mainAbout;

	@FXML
	private Pane proPainPredictor;

	@FXML
	private ImageView proPainPredictorBG;

	@FXML
	private Button proPainPredictorMain;

	@FXML
	private ComboBox<String> proPainPredictorCountry;

	@FXML
	private ComboBox<String> proPainPredictorYear;

	@FXML
	private Button proPainPredictorPredict;

	@FXML
	private Text proPanePredictorAlertText;

	@FXML
	private Pane proPainPredictorResult;

	@FXML
	private ImageView proPainPredictorResultBG;

	@FXML
	private Button proPainPredictorResultMain;

	@FXML
	private Button proPainPredictorResultAgain;

	@FXML
	private TextArea proPanePredictorResultFinal;

	@FXML
	private Pane proPaneComparator;

	@FXML
	private ImageView proPaneComparatorBG;

	@FXML
	private Button proPaneComparatorCompare;

	@FXML
	private Button proPaneComparatorMain;

	@FXML
	private ComboBox<String> proPaneComparatorCountry1;

	@FXML
	private ComboBox<String> proPaneComparatorCountry2;

	@FXML
	private ComboBox<String> proPaneComparatorYear;

	@FXML
	private Text proPaneComparatorAlertText;

	@FXML
	private Pane proPaneComparatorResult;

	@FXML
	private ImageView proPaneComparatorResultBG;

	@FXML
	private Button proPaneComparatorResultAgain;

	@FXML
	private Button proPaneComparatorResultMain;

	@FXML
	private TextArea proPaneComparatorResultCountry1;

	@FXML
	private TextArea proPaneComparatorResultCountry2;

	@FXML
	private TextArea proPaneComparatorResultCountry11;

	@FXML
	private Pane abtPane;

	@FXML
	private ImageView abtPaneBG;

	@FXML
	private Button abtPaneMain;

	void changeState(int newState) {
		calc.setMachState(newState);
		UIupdate();
	}

	void UIupdate() { // Updates UI pane to current machine state
		System.out.println("X");
		if (calc.machStateChange()) {
			switch (calc.getMachState()) { // Changes visibility of panes for the purpose of changing views
			case 0:
				startPane.setVisible(true);
				mainPane.setVisible(false);
				proPainPredictor.setVisible(false);
				proPainPredictorResult.setVisible(false);
				proPaneComparator.setVisible(false);
				proPaneComparatorResult.setVisible(false);
				abtPane.setVisible(false);
				break;
			case 1:
				startPane.setVisible(false);
				mainPane.setVisible(true);
				proPainPredictor.setVisible(false);
				proPainPredictorResult.setVisible(false);
				proPaneComparator.setVisible(false);
				proPaneComparatorResult.setVisible(false);
				abtPane.setVisible(false);
				break;
			case 2:
				startPane.setVisible(false);
				mainPane.setVisible(false);
				proPainPredictor.setVisible(true);
				proPainPredictorResult.setVisible(false);
				proPaneComparator.setVisible(false);
				proPaneComparatorResult.setVisible(false);
				abtPane.setVisible(false);
				break;
			case 3:
				startPane.setVisible(false);
				mainPane.setVisible(false);
				proPainPredictor.setVisible(false);
				proPainPredictorResult.setVisible(true);
				proPaneComparator.setVisible(false);
				proPaneComparatorResult.setVisible(false);
				abtPane.setVisible(false);
				break;
			case 4:
				startPane.setVisible(false);
				mainPane.setVisible(false);
				proPainPredictor.setVisible(false);
				proPainPredictorResult.setVisible(false);
				proPaneComparator.setVisible(true);
				proPaneComparatorResult.setVisible(false);
				abtPane.setVisible(false);
				break;
			case 5:
				startPane.setVisible(false);
				mainPane.setVisible(false);
				proPainPredictor.setVisible(false);
				proPainPredictorResult.setVisible(false);
				proPaneComparator.setVisible(false);
				proPaneComparatorResult.setVisible(true);
				abtPane.setVisible(false);
				break;
			case 6:
				startPane.setVisible(false);
				mainPane.setVisible(false);
				proPainPredictor.setVisible(false);
				proPainPredictorResult.setVisible(false);
				proPaneComparator.setVisible(false);
				proPaneComparatorResult.setVisible(false);
				abtPane.setVisible(true);
				break;
			default:
				calc.setMachState(1);
				break;
			}

			switch (calc.getMachState()) {
			case 0: // Nothing to do!
				break;
			case 1: // Nothing here to!
				break;
			case 2: // Configure countries to prepare for calculations

				proPainPredictorCountry.setItems(countryList);
				proPainPredictorYear.setItems(yearList);
				break;

			case 3: // Ready output for single country prediction.
				proPanePredictorResultFinal.setText(
						calc.getPredictionResult(proPainPredictorCountry.getSelectionModel().getSelectedIndex(),
								proPainPredictorYear.getSelectionModel().getSelectedIndex()));

				break;

			case 4:
				proPaneComparatorCountry1.setItems(countryList);
				proPaneComparatorCountry2.setItems(countryList);
				proPaneComparatorYear.setItems(yearList);
				break;
			case 5:
				calc.compareCountries(proPaneComparatorCountry1.getSelectionModel().getSelectedIndex(),
						proPaneComparatorCountry2.getSelectionModel().getSelectedIndex(),
						proPaneComparatorYear.getSelectionModel().getSelectedIndex());
				proPaneComparatorResultCountry1.setText(calc.getPredictionResultCountryOne());
				proPaneComparatorResultCountry2.setText(calc.getPredictionResultCountryTwo());
				proPaneComparatorResultCountry11.setText(calc.getComparisonResult());
				break;

			default:

			}
		}

		calc.confirmMachineStateChange();
	}
}
